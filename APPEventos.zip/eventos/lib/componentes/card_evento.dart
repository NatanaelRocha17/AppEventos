import 'package:eventos/estado.dart';
import 'package:flutter/material.dart';


class CardEvento extends StatelessWidget {
  final dynamic evento;

  const CardEvento({super.key, required this.evento});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Verificando se o evento e o ID existem
        if (evento != null && evento["_id"] != null) {
          estadoApp.mostrarDetalhes(evento["_id"]); // Usando estadoApp como no Card_Evento
        
        } else {
          print("Erro: Evento ou ID inválido"); // Log para debug
        }
      },
      child: Card(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagem do evento
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12.0)),
              child: Image.asset(
                'lib/recursos/imagens/image (2).png', // Pode ser uma imagem do evento
                fit: BoxFit.cover,
                height: 160,
                width: double.infinity,
              ),
            ),

            // Linha com o nome do evento
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                evento["event"]["name"] ?? "Evento sem título",
                style: const TextStyle(
                  fontSize: 17, 
                  fontWeight: FontWeight.bold
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),

            // Descrição do evento
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Text(
                evento["event"]["description"] ?? "Sem descrição disponível.",
                style: const TextStyle(fontSize: 14),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ),

            // Preço e likes
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Likes
                  Row(
                    children: [
                      const Icon(Icons.thumb_up_alt_rounded, 
                        color: Color.fromARGB(255, 13, 116, 235), 
                        size: 18),
                      const SizedBox(width: 4.0),
                      Text(
                        evento["event"]["likes"]?.toString() ?? "0", // Número de curtidas
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                  ),

                  // Preço
                  Text(
                    "R\$ ${evento["event"]["price"]?.toStringAsFixed(2) ?? "0.00"}",
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
