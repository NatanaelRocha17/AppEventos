import 'dart:convert';
import 'package:flat_list/flat_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:eventos/componentes/card_evento.dart';
import 'package:eventos/estado.dart';
import 'package:toast/toast.dart';

class EventosWidget extends StatefulWidget {
  const EventosWidget({super.key});

  @override
  State<StatefulWidget> createState() {
    return _EstadoEventosWidget();
  }
}

const int tamanhoDaPagina = 4;

class _EstadoEventosWidget extends State<EventosWidget> {
  late dynamic _feedComEventos;
  bool _carregando = false;
  List<dynamic> _eventos = [];
  final TextEditingController _controladorDoFiltro = TextEditingController();
  String _filtro = "";
  int _proximaPagina = 1;

  @override
  void initState() {
    super.initState();
     ToastContext().init(context);
    _lerFeedEstatico();
  }

  Future<void> _lerFeedEstatico() async {
    final String resposta =
        await rootBundle.loadString('lib/recursos/jsons/feedDeEventos.json');
    _feedComEventos = await jsonDecode(resposta);
    _carregarEventos();
  }

  void _carregarEventos() {
    setState(() {
      _carregando = true;
    });

    if (_filtro.isNotEmpty) {
      try {
        // Aplicando o filtro nos eventos
        _eventos = _feedComEventos["eventos"]
            .where((evento) => evento["event"]["name"]
                .toString()
                .toLowerCase()
                .contains(_filtro.toLowerCase()))
            .toList();
      } catch (e) {
        print("Erro ao filtrar eventos: $e");
        _eventos = []; // Retornar uma lista vazia em caso de erro
      }
    } else {
      final totalDeEventosParaCarregar = _proximaPagina * tamanhoDaPagina;
      try {
        if (_feedComEventos["eventos"].length >= totalDeEventosParaCarregar) {
          _eventos =
              _feedComEventos["eventos"].sublist(0, totalDeEventosParaCarregar);
        }
        print(
            "Carregando eventos: ${_eventos.length} de ${_feedComEventos["eventos"].length}");
      } catch (e) {
        print("Erro ao carregar eventos paginados: $e");

      }
    }

    setState(() {
      _carregando = false;
      _proximaPagina++;
    });
  }

  Future<void> _atualizarEventos() async {
    _eventos = [];
    _proximaPagina = 1;
    _controladorDoFiltro.text = "";
    _filtro = "";
    _carregarEventos();
  }

  void _aplicarFiltro(String filtro) {
    _filtro = filtro.toLowerCase();
    _carregarEventos();
  }

  Future<void> _toggleLoginStatus() async {
    setState(() {
      _carregando = true;
    });

    if (estadoApp.usuario != null) {
      await estadoApp.logoff(); // Utiliza o método logoff do estado
      Toast.show("Usuário deslogado",
          duration: Toast.lengthShort, gravity: Toast.bottom);
    } else {
      await estadoApp.login(); // Utiliza o método login do estado
      Toast.show("Usuário logado",
          duration: Toast.lengthShort, gravity: Toast.bottom);
    }

    setState(() {
      _carregando = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    // Exibe um indicador de carregamento enquanto os dados estão sendo carregados
    return _carregando
        ? const Center(child: CircularProgressIndicator())
        : Scaffold(
            appBar: AppBar(
              actions: [
                // Campo de busca
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        top: 10, bottom: 10, left: 60, right: 20),
                    child: TextField(
                      controller: _controladorDoFiltro,
                      onSubmitted: (filtro) {
                        _aplicarFiltro(filtro);
                      },
                      cursorColor: const Color(0xFFFF5722), // Cor do cursor
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(), // Borda normal
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFFFF5722),
                          ), // Cor da borda focada
                        ),
                        suffixIcon: Icon(Icons.search),
                        hintText: "Busque pelo evento", // Placeholder
                        hintStyle: TextStyle(fontSize: 12),
                        contentPadding: EdgeInsets.symmetric(
                            vertical: 0), // Centraliza verticalmente
                        filled: true, // Ativa o preenchimento do campo
                        fillColor: Colors.white, // Cor de fundo branca
                      ),
                    ),
                  ),
                ),
                // Botão de login/logout
                IconButton(
                  onPressed: _toggleLoginStatus, // Alterna o login/logout
                  icon: Icon(
                    estadoApp.usuario != null
                        ? Icons.logout
                        : Icons
                            .login, // Altera o ícone com base no estado de login
                    color: Colors.white,
                  ),
                  tooltip: estadoApp.usuario != null
                      ? 'Sair'
                      : 'Entrar', // Tooltip baseado no estado de login
                ),
              ],
            ),
            body: _eventos.isEmpty
                ? const Center(
                    child: Text(
                      "Nenhum evento encontrado.",
                      style: TextStyle(fontSize: 18, color: Colors.grey),
                    ),
                  )
                : FlatList(
                    data: _eventos,
                    loading: _carregando,
                    numColumns: 2,
                    onRefresh: () => _atualizarEventos(),
                    onEndReached: () => _carregarEventos(),
                    buildItem: (item, index) {
                      return SizedBox(
                        height: estadoApp.altura * 0.40,
                        child: CardEvento(evento: item),
                      );
                    },
                  ),
          );
  }
}
