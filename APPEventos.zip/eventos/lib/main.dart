import 'package:flutter/material.dart';
import 'package:eventos/estado.dart';
import 'package:provider/provider.dart';
import 'package:eventos/navegacao/detalhes_evento.dart';
import 'package:eventos/navegacao/eventos.dart';

void main() {
  runApp(const AppEventos());
}

class AppEventos extends StatelessWidget {
  const AppEventos({super.key});



@override
Widget build(BuildContext context) {
  return ChangeNotifierProvider(
    create: (_) => Estado(),
    child: MaterialApp(
      title: 'Eventos para você',
      theme: ThemeData(
        // Definindo a cor do tema principal para laranja
        primarySwatch: Colors.orange, // Cor laranja para o tema principal
        colorScheme: const ColorScheme.light(),
        useMaterial3: true,

        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.orange, // Cor de fundo da AppBar
          titleTextStyle: TextStyle(
            color: Colors.white, // Cor do título na AppBar
            fontSize: 17, // Tamanho do título
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Colors.orange,
        ),
      ),
      home: const TelaPrincipal(title: 'Eventos para você'),
    ),
  );
}


}

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({super.key, required this.title});

  final String title;

  @override
  State<TelaPrincipal> createState() => _EstadoTelaPrincipal();
}

class _EstadoTelaPrincipal extends State<TelaPrincipal> {
  @override
Widget build(BuildContext context) {
  // Acessa o estado global
  estadoApp = context.watch<Estado>();

  // Configura as dimensões da tela após o build
  WidgetsBinding.instance.addPostFrameCallback((_) {
    final media = MediaQuery.of(context);
    estadoApp.setDimensoes(media.size.height, media.size.width);
  });

  // Define a tela que será exibida com base no estado
  Widget tela = const Center(child: Text('Carregando...')); // Fallback padrão
  if (estadoApp.mostrandoEventos()) {
    tela = const EventosWidget(); // Exibe a lista de eventos
  } else if (estadoApp.mostrandoDetalhes()) {
    tela = const DetalhesEventos(); // Exibe os detalhes do evento
  }

  // Retorna a tela selecionada
  return Scaffold(
    appBar: AppBar(
      title: Text(widget.title), // Título dinâmico
    ),
    body: tela, // Corpo da tela, que muda com base no estado
  );
}


}