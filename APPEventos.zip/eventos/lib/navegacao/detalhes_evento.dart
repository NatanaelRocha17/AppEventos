import 'dart:convert';
import 'package:eventos/estado.dart';
import 'package:flat_list/flat_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_view_dot_indicator/page_view_dot_indicator.dart';
import 'package:share_plus/share_plus.dart';
import 'package:toast/toast.dart';


class DetalhesEventos extends StatefulWidget {
  const DetalhesEventos({super.key});

  @override
  State<StatefulWidget> createState() => _DetalhesState();
}

enum _EstadoEvento { naoVerificado, temEvento, semEvento }

class _DetalhesState extends State<DetalhesEventos> {
  late dynamic _feedDeEventos;
  late dynamic _feedDeComentarios;

  _EstadoEvento _temEvento = _EstadoEvento.naoVerificado;
  late dynamic _evento;

  List<dynamic> _comentarios = [];
  bool _carregandoComentarios = false;
  bool _temComentarios = false;

  late TextEditingController _controladorNovoComentario;
  late PageController _controladorSlides;
  late int _slideSelecionado;

  bool _curtiu = false;
  bool _carregandoEvento = true;

  @override
  void initState() {
    super.initState();
    ToastContext().init(context);

    _lerFeedEstatico();
    _iniciarSlides();

    _controladorNovoComentario = TextEditingController();
  }

  void _iniciarSlides() {
    _slideSelecionado = 0;
    _controladorSlides = PageController(initialPage: _slideSelecionado);
  }

  Future<void> _lerFeedEstatico() async {
    setState(() {
      _carregandoEvento = true;
    });

    String conteudoJson =
        await rootBundle.loadString("lib/recursos/jsons/feedDeEventos.json");
    _feedDeEventos = await json.decode(conteudoJson);

    conteudoJson =
        await rootBundle.loadString("lib/recursos/jsons/comentarios.json");
    _feedDeComentarios = await json.decode(conteudoJson);

    _carregarEvento();
    _carregarComentarios();

    setState(() {
      _carregandoEvento = false;
    });
  }

  void _carregarEvento() {
    setState(() {
      _evento = _feedDeEventos["eventos"]
          .firstWhere((evento) => evento["_id"] == estadoApp.idEvento);
    });

    _temEvento =
        _evento != null ? _EstadoEvento.temEvento : _EstadoEvento.semEvento;
  }

  void _carregarComentarios() {
    setState(() {
      _carregandoComentarios = true;
    });

    _comentarios = [];
    var comentariosFiltrados =
        _feedDeComentarios["comentarios"].where((comentario) {
      return comentario["feed"] == estadoApp.idEvento;
    }).toList();

    setState(() {
      _comentarios = comentariosFiltrados;
      _carregandoComentarios = false;
      _temComentarios = _comentarios.isNotEmpty;
    });
  }

  Widget _exibirMensagemEventoInexistente() {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("Eventos"),
            GestureDetector(
              onTap: () => estadoApp.mostrarEventos(),
              child: const Icon(Icons.arrow_back, color: Colors.white),
            )
          ],
        ),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error, size: 32, color: Colors.red),
            Text(
              "Evento inexistente :(",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            Text("Selecione outro evento na tela anterior",
                style: TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _exibirComentarios() {
  return Expanded(
    child: FlatList(
      data: _comentarios,
      loading: _carregandoComentarios,
      buildItem: (item, index) {
        return ListTile(
          title: Text(
            item["user"]["name"] ?? "Autor desconhecido",
            style: const TextStyle(fontSize: 13), 
          ),
          subtitle: Text(
            item["content"] ?? "Sem conteúdo disponível",
            style: const TextStyle(fontSize: 13), 
          ),
        );
      },
    ),
  );
}


void _adicionarComentario() {
  String conteudo = _controladorNovoComentario.text.trim();
  if (conteudo.isNotEmpty) {
    if (_usuarioLogado()) {
      setState(() {
        // Verifique se o nome do usuário está disponível
        if (estadoApp.usuario?.nome == null) {
          Toast.show("Comentário bloqueado. Nome de usuário não vinculado à conta Google.", duration: Toast.lengthLong, gravity: Toast.bottom);
        } else {
          // Adiciona o novo comentário à lista de comentários
          _comentarios.add({
            "user": {"name": estadoApp.usuario!.nome},
            "content": conteudo,
          });

          // Atualiza a variável _temComentarios para indicar que agora temos comentários
          _temComentarios = _comentarios.isNotEmpty;
        }
      });

      // Limpa o campo de texto e exibe uma mensagem de sucesso
      _controladorNovoComentario.clear();
      Toast.show("Comentário adicionado com sucesso", duration: Toast.lengthLong, gravity: Toast.bottom);
    } else {
      Toast.show("Você precisa estar logado para comentar", duration: Toast.lengthLong, gravity: Toast.bottom);
    }
  } else {
    Toast.show("Digite um comentário", duration: Toast.lengthLong, gravity: Toast.bottom);
  }
}

  bool _usuarioLogado() {
    bool usuarioLogado = estadoApp.usuario != null;
    return usuarioLogado; 
  }

  void _comprarIngresso() {
    if (_usuarioLogado()) {
      Toast.show("Redirecionando para compra de ingresso",
          duration: Toast.lengthLong, gravity: Toast.bottom);
    } else {
      Toast.show("Você precisa estar logado para comprar ingresso",
          duration: Toast.lengthLong, gravity: Toast.bottom);
    }
  }

  Widget _exibirEvento() {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Row(
          children: [
            Image.asset('lib/recursos/imagens/calendar.png', width: 50),
            const Spacer(),
            Center(
              child: Text(
                _evento["event"]["name"],
                style: const TextStyle(fontSize: 15),
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => estadoApp.mostrarEventos(),
              child: const Icon(
                Icons.arrow_back,
                size: 30,
                color: Colors.white, // Define a cor do ícone como branco
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 160,
                child: Stack(
                  children: [
                    PageView.builder(
                      itemCount: 3,
                      controller: _controladorSlides,
                      onPageChanged: (index) {
                        setState(() => _slideSelecionado = index);
                      },
                      itemBuilder: (context, pagePosition) {
                        return Image.asset(
                          'lib/recursos/imagens/image (2).png',
                          fit: BoxFit.cover,
                        );
                      },
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              if (_usuarioLogado()) {
                                setState(() {
                                  int currentLikes = int.tryParse(
                                          _evento["event"]["likes"]
                                              .toString()) ??
                                      0;
                                  _evento["event"]["likes"] = _curtiu
                                      ? currentLikes - 1
                                      : currentLikes + 1;
                                  _curtiu = !_curtiu;
                                });
                                Toast.show(
                                  _curtiu
                                      ? "Você curtiu o evento!"
                                      : "Você retirou sua curtida.",
                                  duration: Toast.lengthShort,
                                  gravity: Toast.bottom,
                                );
                              } else {
                                Toast.show(
                                    "Você precisa estar logado para curtir.",
                                    duration: Toast.lengthShort,
                                    gravity: Toast.bottom);
                              }
                            },
                            child: Row(
                              children: [
                                Icon(
                                  Icons.thumb_up_alt_rounded,
                                  color: _curtiu
                                      ? const Color.fromARGB(255, 219, 162, 5)
                                      : const Color.fromARGB(
                                          255, 255, 255, 255),
                                  size: 30,
                                ),
                                const SizedBox(width: 4.0),
                                Text(
                                  (int.tryParse(_evento["event"]["likes"]
                                              .toString()) ??
                                          0)
                                      .toString(),
                                  style: const TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          GestureDetector(
                            onTap: () {
                              Share.share(
                                  "Confira o evento sobre: ${_evento["event"]["description"]}");
                            },
                            child: const Icon(Icons.share,
                                color: Colors.white, size: 30),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              PageViewDotIndicator(
                currentItem: _slideSelecionado,
                count: 3,
                unselectedColor: Colors.black26,
                selectedColor: Colors.blue,
                duration: const Duration(milliseconds: 200),
              ),
              Card(
                child: Column(
                  children: [
                    // Descrição do evento centralizada
                    Text(
                      _evento["event"]["description"],
                      textAlign: TextAlign.center, // Centralizando a descrição
                      style: const TextStyle(fontSize: 13),
                    ),
                    // Exibindo Data, Hora e Local lado a lado com espaço entre eles
                    Padding(
                      padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Data
                          Column(
                            children: [
                              const Text("Data",
                                  style: TextStyle(fontSize: 11,  fontWeight: FontWeight.bold)),
                              Text(
                                _evento["event"]["date"] ??
                                    "Data não disponível",
                                style: const TextStyle(fontSize: 12),
                        
                              ),
                            ],
                          ),
                          // Hora
                          Column(
                            children: [
                              const Text("Hora",
                                  style: TextStyle(fontSize: 11,  fontWeight: FontWeight.bold)),
                              Text(
                                _evento["event"]["time"] ??
                                    "Hora não disponível",
                                style: const TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                          // Local
                          Column(
                            children: [
                              const Text("Local",
                                  style: TextStyle(fontSize: 11,  fontWeight: FontWeight.bold)),
                              Text(
                                _evento["event"]["address"] ??
                                    "Local não disponível",
                                style: const TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // Exibição do valor do ingresso e botão de compra
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: Text(
                            "R\$ ${_evento["event"]["price"]?.toStringAsFixed(2) ?? "0.00"}",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Color.fromARGB(255, 0, 0, 0),
                            ),
                          ),
                        ),
                        const SizedBox(width: 50),
                        ElevatedButton(
                          onPressed: _comprarIngresso,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color.fromARGB(255, 2, 110, 63),
                          ),
                          child: const Text(
                            "Comprar ingresso",
                            style: TextStyle(
                              color: Color.fromARGB(255, 255, 255, 255),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (_temComentarios) _exibirComentarios(),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controladorNovoComentario,
                      decoration: const InputDecoration(
                        labelText: "Adicionar comentário",
                        labelStyle: TextStyle(
                          color: Colors.orange, // Cor laranja do label
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.orange), // Cor laranja da borda
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color:
                                  Colors.orange), // Cor laranja quando em foco
                        ),
                      ),
                      style: const TextStyle(
                        color: Colors.orange, // Cor laranja do texto
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: _adicionarComentario,
                  ),
                ],
              ),
            ],
          ),
          if (_carregandoEvento)
            const Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget detalhes = const SizedBox.shrink();

    if (_temEvento == _EstadoEvento.naoVerificado) {
      detalhes = const SizedBox.shrink();
    } else if (_temEvento == _EstadoEvento.temEvento) {
      detalhes = _exibirEvento();
    } else {
      detalhes = _exibirMensagemEventoInexistente();
    }

    return detalhes;
  }
}
